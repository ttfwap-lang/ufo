@echo off
:: Check for Administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process '%~dpnx0' -Verb RunAs"
    exit /b
)

title UFO Comprehensive Observer (Elevated)
cd /d C:\ufo\ufo
call scripts\observe_all.bat
pause
