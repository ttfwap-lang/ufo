@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title BankFidelity + UFO Master Configuration Dashboard

:: Check for Administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c cd /d ""%~dp0"" & ""%~nx0"" %*' -Verb RunAs"
    exit /b
)

set "UFO_ROOT=C:\ufo\ufo"
set "PYTHON_EXE=%UFO_ROOT%\python_env\python.exe"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUTF8=1"
set "PYTHONPATH=C:\ufo"

if not exist "%PYTHON_EXE%" (
    echo [FATAL] python_env not found at %PYTHON_EXE%.
    echo The UFO virtual environment is required. Cannot proceed.
    pause
    exit /b 1
)

cd /d "C:\ufo"
"%PYTHON_EXE%" "%UFO_ROOT%\scripts\advanced_settings.py"

endlocal
