Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """C:\ufo\ufo\python_env\pythonw.exe"" ""C:\ufo\ufo\scripts\relay_server.py""", 0, False
