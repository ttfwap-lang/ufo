@echo off
setlocal EnableDelayedExpansion
title Sequential Endpoint Execution (Interactive/GUI nodes)
color 0B
chcp 65001 >nul

:: Check for Administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c cd /d ""%~dp0"" & ""%~nx0"" %*' -Verb RunAs"
    exit /b
)

set "UFO_ROOT=C:\ufo\ufo"
set "PYTHON_EXE=%UFO_ROOT%\python_env\python.exe"
set "BF_DIR=C:\bankfidelity\bankfidelity"

echo ==============================================================
echo  SEQUENTIAL ENDPOINT EXECUTION ^(19 Interactive/GUI Nodes^)
echo ==============================================================
echo.
echo Press any key to run the next endpoint. Some will spawn new
echo windows. Close them or switch back here to continue.
echo.
pause

echo.
echo [01 - 1] Launch BankFidelity GUI ^(PowerShell^)
cd /d "%BF_DIR%"
start "BankFidelity GUI" powershell.exe -ExecutionPolicy Bypass -File "launch.ps1"
pause

echo.
echo [01 - 2] Launch BankFidelity GUI ^(Bash^)
start "BankFidelity Bash GUI" bash "launch.sh"
pause

echo.
echo [01 - 3] Launch PDF_SITCH Terminal ^(CMD^)
start "PDF_SITCH Terminal UI" cmd /k "cargo run --release"
pause

echo.
echo [01 - 4] Boot Headless HTTP Server
start "HTTP Server" cmd /k "cargo run --release -- serve"
pause

echo.
echo [01 - 5] Boot MCP Server
start "MCP Server" cmd /k "cargo run --release -- mcp"
pause

echo.
echo [01 - 6] Local LLM Chat Orchestrator
start "Local LLM Chat" cmd /k "cargo run --release -- chat -i 'Hello from sequential test'"
pause

echo.
echo [02 - 1] Run UFO Task ^(Interactive^)
cd /d "%UFO_ROOT%"
start "UFO Task" cmd /k "%PYTHON_EXE% -m ufo --task 'Open calculator'"
pause

echo.
echo [02 - 2] Run UFO Planner ^(Follower Mode^)
start "UFO Follower" cmd /k "%PYTHON_EXE% -m ufo --mode follower --plan dummy.md"
pause

echo.
echo [02 - 4] Launch AI Dream Team
start "Launch Dream Team" cmd /c "call scripts\setup_dream_team.bat"
pause

echo.
echo [03 - 1] Start Dream Team ^(Duplicate^)
start "Launch Dream Team" cmd /c "call scripts\setup_dream_team.bat"
pause

echo.
echo [04 - 1] Cloud Smoke Test
start "Cloud Smoke Test" cmd /k "call scripts\cloud_smoke_test.bat"
pause

echo.
echo [04 - 2] Multi-Agent Showcase
start "Showcase" cmd /k "%PYTHON_EXE% -m ufo --request 'Open Calculator'"
pause

echo.
echo [05 - 1] Launch UFO Admin Shell
start "Admin Shell" cmd /k "call C:\Users\zbook\Desktop\scripts\05_UFO_Admin_Terminal.bat"
pause

echo.
echo [06 - 1] Run E2E Test Bat
start "E2E Test" cmd /k "call C:\Users\zbook\Desktop\scripts\06_Run_UFO_E2E_Test.bat"
pause

echo.
echo [07 - 1] Configuration Dashboard
start "Config Dashboard" cmd /c "call C:\Users\zbook\Desktop\scripts\07_Configuration_Dashboard.bat"
pause

echo.
echo ==============================================================
echo  EXECUTION COMPLETE
echo ==============================================================
pause
